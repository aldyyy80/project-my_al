<form method="POST" action="from3proses.php">
    <label>umur</label>
    <input type="text" name="angka"  />
    <button type="submit">Submit</button>
</form>