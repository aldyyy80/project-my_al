<form method="POST" action="from14proses.php">
    <label>menunjukan elemen-elemen dalam sebuah array menggunakan function</label>
    <input type="text" name="angka"  />
    <button type="submit">Submit</button>
</form>