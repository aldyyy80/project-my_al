<form method="POST" action="from10proses.php">
    <label>menghitung jumlah digit dalam suatu angka</label>
    <input type="text" name="angka"  />
    <button type="submit">Submit</button>
</form>