<form method="POST" action="from14proses.php">
    <label>mengurutkan elemen-elemen dalam sebuah array secara asceding menggunakan function</label>
    <input type="text" name="angka"  />
    <button type="submit">Submit</button>
</form>