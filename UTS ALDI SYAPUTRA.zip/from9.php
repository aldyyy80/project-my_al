<form method="POST" action="from9proses.php">
    <label>menampilkan deret fibonacci dengan panjang tertentu</label>
    <input type="text" name="angka"  />
    <button type="submit">Submit</button>
</form>