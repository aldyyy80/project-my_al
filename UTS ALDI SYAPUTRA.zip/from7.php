<form method="POST" action="from7proses.php">
    <label>mencetak angka genap</label>
    <input type="text" name="angka"  />
    <button type="submit">Submit</button>
</form>