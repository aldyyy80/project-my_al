<form method="POST" action="from1proses.php">
    <label>Angka</label>
    <input type="text" name="angka"  />
    <button type="submit">Submit</button>
</form>
