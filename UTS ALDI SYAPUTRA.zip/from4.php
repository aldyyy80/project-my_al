<form method="POST" action="from4proses.php">
    <label>kata</label>
    <input type="text" name="angka"  />
    <button type="submit">Submit</button>
</form>
