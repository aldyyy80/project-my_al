<form method="POST" action="from6proses.php">
    <label>cetak angka</label>
    <input type="text" name="angka"  />
    <button type="submit">Submit</button>
</form>