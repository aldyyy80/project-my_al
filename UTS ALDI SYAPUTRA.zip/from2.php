<form method="POST" action="from2proses.php">
    <label>tahun</label>
    <input type="text" name="angka"  />
    <button type="submit">Submit</button>
</form>
