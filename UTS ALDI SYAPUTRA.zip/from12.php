<form method="POST" action="from12proses.php">
    <label>mengalikan elemen-elemen dalam sebuah array menggunakan function</label>
    <input type="text" name="angka"  />
    <button type="submit">Submit</button>
</form>