<?php
//mencetak angka dari 1 hingga 5 menggunakan loop for

for ($i = 1; $i <=  5; $i++) {
    echo $i . " ";
}