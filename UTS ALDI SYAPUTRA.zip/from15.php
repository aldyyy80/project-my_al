<form method="POST" action="from15proses.php">
    <label>mencari rata-rata dari nilai-nilai dalam sebuah array menggunakan
</label>
    <input type="text" name="angka"  />
    <button type="submit">Submit</button>
</form>