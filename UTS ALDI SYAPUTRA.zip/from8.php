<form method="POST" action="from8proses.php">
    <label>menemukan faktorial dari suatu angka</label>
    <input type="text" name="angka"  />
    <button type="submit">Submit</button>
</form>