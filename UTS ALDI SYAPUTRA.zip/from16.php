<form method="POST" action="from16proses.php">
    <label>menunjukan logika dasar untuk menghitunng total belanja pada keranjang belanja</label>
    <input type="text" name="angka"  />
    <button type="submit">Submit</button>
</form>