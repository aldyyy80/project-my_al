<form method="POST" action="from5proses.php">
    <label>kode menu</label>
    <input type="text" name="angka"  />
    <button type="submit">Submit</button>
</form>