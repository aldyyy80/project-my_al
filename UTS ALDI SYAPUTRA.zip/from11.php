<form method="POST" action="from11proses.php">
    <label>menunjukan elemen-elemen dalam sebuah array menggunakan function</label>
    <input type="text" name="angka"  />
    <button type="submit">Submit</button>
</form>